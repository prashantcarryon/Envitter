<?php
include '../connect.php';
/*$json = file_get_contents('php://input');
$obj = json_decode($json);
print_r(json_encode($obj));*/
$value = json_decode(file_get_contents('php://input'));

$details = array(
    "donor_id" => $value->{'id'},
    "newspaper" => $value->{'newspaper'},
    "others" => $value->{'otheritems'},
    "present" => $value->{'present'},
    "latitude" => $value->{'lat'},
    "longitude" => $value->{"lng"}
);

$db->collection_details->insert($details);
?>
