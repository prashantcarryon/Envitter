<?php
include '../connect.php';
/*$json = file_get_contents('php://input');
$obj = json_decode($json);
print_r(json_encode($obj));*/
$value = json_decode(file_get_contents('php://input'));
$details = array("name"=>$_POST['name'], "address"=>$_POST['address'],
"location=>$_POST['location'], "contact"=>$_POST['contact'], "collector"=>$_POST['collector'];

$db->users->insert($details);

?>
