<?php
include '../connect.php';
$items = $db->donors->find(array(
    "visit_date"=> date('Y-m-d')
    )
);
$json_object = array();
foreach($items as $item){
    $temp = array(
        "name" => $item["name"],
        "flat_no" => $item['flat_no'],
        "building" => $item['building'],
        "address" => $item["address"],
        "contact" => $item["contact"],
        "latitude" => $item["latitude"],
        "longitude" => $item["longitude"],
        "location" => $item["location"],
        "id" => strval($item["_id"]),
        "collector_name" => $item["collector_name"]
    );
    array_push($json_object, $temp);
}
echo json_encode($json_object, JSON_PRETTY_PRINT);
?>
