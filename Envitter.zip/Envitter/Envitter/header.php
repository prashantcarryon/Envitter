<!DOCTYPE html>
<html>
<head>
   <title>MESCO | Admin</title>
   <meta name="viewport" content="width=device-width, initial-scale=1">

   <!-- Fonts -->
   <link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:300,400' rel='stylesheet' type='text/css'>
   <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700,900' rel='stylesheet' type='text/css'>
   <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" rel='stylesheet' type='text/css'>
   <!-- Latest compiled and minified CSS -->
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"
   integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
   <!-- Data tables css -->
   <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.10/css/dataTables.bootstrap.css">
   <!-- CSS App -->
   <link rel="stylesheet" type="text/css" href="css/style.css">
   <link rel="stylesheet" type="text/css" href="css/flat-blue.css">

   <!--Let browser know website is optimized for mobile-->
   <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

   <!-- Favicon -->
   <link rel="shortcut icon" href="images/favicon.ico">
   <style>
   #map {
      width: 100%;
      height: 400px;
   }
   .controls {
      margin-top: 10px;
      border: 1px solid transparent;
      border-radius: 2px 0 0 2px;
      box-sizing: border-box;
      -moz-box-sizing: border-box;
      height: 32px;
      outline: none;
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
   }

   #pac-input {
      background-color: #fff;
      font-family: Roboto;
      font-size: 15px;
      font-weight: 300;
      margin-left: 12px;
      padding: 0 11px 0 13px;
      text-overflow: ellipsis;
      width: 300px;
   }

   #pac-input:focus {
      border-color: #4d90fe;
   }

   .pac-container {
      font-family: Roboto;
   }

   #type-selector {
      color: #fff;
      background-color: #4d90fe;
      padding: 5px 11px 0px 11px;
   }

   #type-selector label {
      font-family: Roboto;
      font-size: 13px;
      font-weight: 300;
   }
   #target {
      width: 345px;
   }
   </style>
   <script type="text/javascript">
   /*
   * heatmap.js gmaps overlay
   *
   * Copyright (c) 2014, Patrick Wied (http://www.patrick-wied.at)
   * Dual-licensed under the MIT (http://www.opensource.org/licenses/mit-license.php)
   * and the Beerware (http://en.wikipedia.org/wiki/Beerware) license.
   */

   (function (name, context, factory) {

     // Supports UMD. AMD, CommonJS/Node.js and browser context
     if (typeof module !== "undefined" && module.exports) {
       module.exports = factory();
     } else if (typeof define === "function" && define.amd) {
       define(factory);
     } else {
       context[name] = factory();
     }

   })("HeatmapOverlay", this, function() {

     var HeatmapOverlay = function(map, cfg){
       this.setMap(map);
       this.initialize(cfg || {});
     };

     HeatmapOverlay.prototype = new google.maps.OverlayView();


     HeatmapOverlay.CSS_TRANSFORM = (function() {
       var div = document.createElement('div');
       var props = [
         'transform',
         'WebkitTransform',
         'MozTransform',
         'OTransform',
         'msTransform'
       ];

       for (var i = 0; i < props.length; i++) {
         var prop = props[i];
         if (div.style[prop] !== undefined) {
           return prop;
         }
       }

       return props[0];
     })();

     HeatmapOverlay.prototype.initialize = function(cfg) {
       this.cfg = cfg;

       var map = this.map = this.getMap();
       var container = this.container = document.createElement('div');
       var mapDiv = map.getDiv();
       var width = this.width = mapDiv.clientWidth;
       var height = this.height = mapDiv.clientHeight;

       container.style.cssText = 'width:' + width +'px;height:' + height+'px;';

       this.data = [];
       this.max = 1;
       this.min = 0;

       cfg.container = container;
     };

     HeatmapOverlay.prototype.onAdd = function(){
       var h337 = typeof require !== 'undefined' ? require('heatmap.js') : window.h337;
       var that = this;

       this.getPanes().overlayLayer.appendChild(this.container);


       this.changeHandler = google.maps.event.addListener(
         this.map,
         'bounds_changed',
         function() { return that.draw(); }
       );

       if (!this.heatmap) {
         this.heatmap = h337.create(this.cfg);
       }
       this.draw();
     };

     HeatmapOverlay.prototype.onRemove = function() {
       if (!this.map) { return; }

       this.map = null;

       this.container.parentElement.removeChild(this.container);

       if (this.changeHandler) {
         google.maps.event.removeListener(this.changeHandler);
         this.changeHandler = null;
       }

     };

     HeatmapOverlay.prototype.draw = function() {
       if (!this.map) { return; }

       var bounds = this.map.getBounds();

       var topLeft = new google.maps.LatLng(
         bounds.getNorthEast().lat(),
         bounds.getSouthWest().lng()
       );

       var projection = this.getProjection();
       var point = projection.fromLatLngToDivPixel(topLeft);

       this.container.style[HeatmapOverlay.CSS_TRANSFORM] = 'translate(' +
           Math.round(point.x) + 'px,' +
           Math.round(point.y) + 'px)';

       this.update();
     };

     HeatmapOverlay.prototype.resize = function() {

       if (!this.map){ return; }

       var div = this.map.getDiv(),
         width = div.clientWidth,
         height = div.clientHeight;

       if (width == this.width && height == this.height){ return; }

       this.width = width;
       this.height = height;

       // update heatmap dimensions
       this.heatmap._renderer.setDimensions(width, height);
       // then redraw all datapoints with update
       this.update();
     };

     HeatmapOverlay.prototype.update = function() {
       var projection = this.getProjection(),
         zoom, scale, bounds, topLeft;
       var generatedData = { max: this.max, min: this.min, data: [] };

       if (!projection){ return; }

       bounds = this.map.getBounds();

       topLeft = new google.maps.LatLng(
         bounds.getNorthEast().lat(),
         bounds.getSouthWest().lng()
       );

       zoom = this.map.getZoom();
       scale = Math.pow(2, zoom);

       this.resize();

       if (this.data.length == 0) {
         if (this.heatmap) {
           this.heatmap.setData(generatedData);
         }
         return;
       }


       var latLngPoints = [];
       // iterate through data
       var len = this.data.length;
       var layerProjection = this.getProjection();
       var layerOffset = layerProjection.fromLatLngToDivPixel(topLeft);
       var radiusMultiplier = this.cfg.scaleRadius ? scale : 1;
       var localMax = 0;
       var localMin = 0;
       var valueField = this.cfg.valueField;


       while (len--) {
         var entry = this.data[len];
         var value = entry[valueField];
         var latlng = entry.latlng;


         // we don't wanna render points that are not even on the map ;-)
         if (!bounds.contains(latlng)) {
           continue;
         }
         // local max is the maximum within current bounds
         localMax = Math.max(value, localMax);
         localMin = Math.min(value, localMin);

         var point = layerProjection.fromLatLngToDivPixel(latlng);
         var latlngPoint = { x: Math.round(point.x - layerOffset.x), y: Math.round(point.y - layerOffset.y) };
         latlngPoint[valueField] = value;

         var radius;

         if (entry.radius) {
           radius = entry.radius * radiusMultiplier;
         } else {
           radius = (this.cfg.radius || 2) * radiusMultiplier;
         }
         latlngPoint.radius = radius;
         latLngPoints.push(latlngPoint);
       }
       if (this.cfg.useLocalExtrema) {
         generatedData.max = localMax;
         generatedData.min = localMin;
       }

       generatedData.data = latLngPoints;

       this.heatmap.setData(generatedData);

     };

     HeatmapOverlay.prototype.setData = function(data) {
       this.max = data.max;
       this.min = data.min;

       var latField = this.cfg.latField || 'lat';
       var lngField = this.cfg.lngField || 'lng';
       var valueField = this.cfg.valueField || 'value';

       // transform data to latlngs
       var data = data.data;
       var len = data.length;
       var d = [];

       while (len--) {
         var entry = data[len];
         var latlng = new google.maps.LatLng(entry[latField], entry[lngField]);
         var dataObj = { latlng: latlng };
         dataObj[valueField] = entry[valueField];
         if (entry.radius) {
           dataObj.radius = entry.radius;
         }
         d.push(dataObj);
       }
       this.data = d;
       this.update();
     };
     // experimential. not ready yet.
     HeatmapOverlay.prototype.addData = function(pointOrArray) {
       if (pointOrArray.length > 0) {
           var len = pointOrArray.length;
           while(len--) {
             this.addData(pointOrArray[len]);
           }
         } else {
           var latField = this.cfg.latField || 'lat';
           var lngField = this.cfg.lngField || 'lng';
           var valueField = this.cfg.valueField || 'value';
           var entry = pointOrArray;
           var latlng = new google.maps.LatLng(entry[latField], entry[lngField]);
           var dataObj = { latlng: latlng };

           dataObj[valueField] = entry[valueField];
           if (entry.radius) {
             dataObj.radius = entry.radius;
           }
           this.max = Math.max(this.max, dataObj[valueField]);
           this.min = Math.min(this.min, dataObj[valueField]);
           this.data.push(dataObj);
           this.update();
         }
     };

     return HeatmapOverlay;

   });


   </script>
   <script type="text/javascript">

   var myLatlng = new google.maps.LatLng(25.6586, -80.3568);
// map options,
var myOptions = {
  zoom: 3,
  center: myLatlng
};
// standard map
map = new google.maps.Map(document.getElementById("map-canvas"), myOptions);
// heatmap layer
heatmap = new HeatmapOverlay(map,
  {
    // radius should be small ONLY if scaleRadius is true (or small radius is intended)
    "radius": 2,
    "maxOpacity": 1,
    // scales the radius based on map zoom
    "scaleRadius": true,
    // if set to false the heatmap uses the global maximum for colorization
    // if activated: uses the data maximum within the current map boundaries
    //   (there will always be a red spot with useLocalExtremas true)
    "useLocalExtrema": true,
    // which field name in your data represents the latitude - default "lat"
    latField: 'lat',
    // which field name in your data represents the longitude - default "lng"
    lngField: 'lng',
    // which field name in your data represents the data value - default "value"
    valueField: 'count'
  }
);

var testData = {
  max: 8,
  data: [{lat: 24.6408, lng:46.7728, count: 3},{lat: 50.75, lng:-1.55, count: 1}]
};

heatmap.setData(testData);


            //alert(marker.getPosition().toString());

      }
      </script>
      <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAwYiLOK-lCV7Y_vcxNeFh1Ix-MueSyUgE&libraries=places" async defer></script>
   </head>

   <body class="flat-blue">
