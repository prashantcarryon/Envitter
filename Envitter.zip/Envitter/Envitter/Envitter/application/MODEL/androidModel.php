<?php
class androidModel extends CI_Model {

        public function __construct()
        {
                $this->load->database();
        }
        public function insertDescription($cat_id,$lat,$long,$desc,$imgurl){

          $data=array('cat_id'=>$cat_id,'lat'=>$lat,'long'=>$long,'description'=>$desc,'image'=>$imgurl,'status'=>"Pending");
          $this->db->insert('issues',$data);

        }

        public function getidissues(){

          $maxid = 0;
          $row = $this->db->query('SELECT MAX(id) AS `maxid` FROM `issues`')->row();
          if ($row) {
            $maxid = $row->maxid;
          }

          return $maxid;

        }

        public function getlistModel(){
          $this->db->select("image, description, agg_count, disagg_count, status, assign_id,cat_id");
          $this->db->from("issues");
  //       $this->db->orderby("id", "DESC");
          $query = $this->db->get();
          return array_reverse($query->result());
        }


}
