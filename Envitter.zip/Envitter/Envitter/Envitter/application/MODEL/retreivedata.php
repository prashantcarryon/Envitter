<?php
class retreivedata extends CI_Model {

        public function __construct()
        {
                $this->load->database();
        }

        public function getData(){
          $query=$this->db->get('cat_name');
          return $query->result();
        }

        public function getData1(){
          $query=$this->db->get('assigned');
          return $query->result();
        }

        public function getData2(){
          $query=$this->db->get('issues');
          return $query->result();
        }

        public function insertassigned($name,$cat_id,$contact){
         $data=array('person'=>$name,'contact'=>$contact,'cat_id'=>$cat_id,'available'=>1);
         $this->db->insert('assigned',$data);
        }

        public function populatePersonListModel($catid)
        {
        $this->db->select('id,person');
        $this->db->from('assigned');
        $this->db->where('cat_id',$catid);
        $this->db->where('available',1);
        $query = $this->db->get();
        return $query->result();
        }

        public function assign_issueModel($idissue,$idassigned){
          $data = array(
               'assign_id' => $idassigned
            );
            $data1=array(
              'available'=>0
            );
            $this->db->where('id', $idissue);
            $this->db->update('issues', $data);
            $this->db->where('id', $idassigned);
            $this->db->update('assigned', $data1);

        }


}
