<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<html>
<body>
<h1>Hello world</h1>
<p><?php echo $title; ?></p>
</body>
</html>
