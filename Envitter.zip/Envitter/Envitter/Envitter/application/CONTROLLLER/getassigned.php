<?php

class getassigned extends CI_Controller {
  public function index()
  {
    $this->load->model('retreivedata');
    $data['records']=$this->retreivedata->getData1();
    print_r(json_encode($data));
  }

  public function populatePersonList()
  {
    $this->load->model('retreivedata');
    $postdata=file_get_contents("php://input");
    $request=json_decode($postdata);
    $catid=$request->cat_id;
    $data['records']=$this->retreivedata->populatePersonListModel($catid);
    print_r(json_encode($data));
  }

  public function assign_issue()
  {
      $this->load->model('retreivedata');
      $postdata=file_get_contents("php://input");
      $request=json_decode($postdata);
      $issue=$request->issueid;
      $assigned=$request->personid;
      $this->retreivedata->assign_issueModel($issue,$assigned);

  }



}

 ?>
