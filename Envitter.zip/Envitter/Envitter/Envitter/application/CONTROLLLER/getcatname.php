<?php

class getcatname extends CI_Controller {
  public function index()
  {
    $this->load->model('retreivedata');
    $data['records']=$this->retreivedata->getData2();
    print_r(json_encode($data));
  }


}

 ?>
